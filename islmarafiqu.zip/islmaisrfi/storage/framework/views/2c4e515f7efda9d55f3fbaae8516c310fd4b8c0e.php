<?php $__env->startSection('content'); ?>

    <h3>Products</h3>

<ul class="container">
    <?php $__empty_1 = true; foreach($products as $product): $__empty_1 = false; ?>
    <li class="row">


       <div class="col-md-8">
        <h4>Name of product:<?php echo e($product->name); ?></h4>
        <h4>Category:<?php echo e(count($product->category)?$product->category->name:"N/A"); ?></h4>
 <a href="<?php echo e(route('products.edit',$product ->id)); ?>"class="btn btn-primary btn-sm  "></a>

      <br>

       
           <?php echo e(csrf_field()); ?>

           <?php echo e(method_field('DELETE')); ?>

           <input class="btn btn-sm btn-danger" type="submit" value="">
         </form>

         <div class="col-md-4">
            
            <form action="/admin/products/image-upload/<?php echo e($product->id); ?>" method="POST" class="dropzone" id="my-awesome-dropzone-<?php echo e($product->id); ?>">
              <?php echo e(csrf_field()); ?>


             </form>

        </div>

    </li>

        <?php endforeach; if ($__empty_1): ?>

        <h3>No products</h3>

    <?php endif; ?>
</ul>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>