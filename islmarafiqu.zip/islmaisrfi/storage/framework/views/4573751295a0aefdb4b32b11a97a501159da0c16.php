<?php $__env->startSection('content'); ?>
    <h3>Orders</h3>
    <hr>

    <ul>
        <?php foreach($orders as $order): ?>
            <li>
                <h4>Order by <?php echo e($order->user->name); ?> <br> Total Price <?php echo e($order->total); ?></h4>

                <form action="<?php echo e(route('toggle.deliver',$order->id)); ?>" method="POST" class="pull-right" id="deliver-toggle">
                    <?php echo e(csrf_field()); ?>

                    <label for="delivered">Delivered</label>
                    <input type="checkbox" value="1" name="delivered"  <?php echo e($order->delivered==1?"checked":""); ?>>
                    <input type="submit" value="Submit">
                </form>

                <div class="clearfix"></div>
                <hr>
                <h5>Items</h5>
                <table class="table table-bordered">
                    <tr>
                        <th>Name</th>
                        <th>qty</th>
                        <th>price</th>
                    </tr>
                    <?php foreach($order->orderItems as $item): ?>
                        <tr>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->pivot->qty); ?></td>
                            <td><?php echo e($item->pivot->total); ?></td>
                        </tr>

                    <?php endforeach; ?>
                </table>
            </li>

        <?php endforeach; ?>

    </ul>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>