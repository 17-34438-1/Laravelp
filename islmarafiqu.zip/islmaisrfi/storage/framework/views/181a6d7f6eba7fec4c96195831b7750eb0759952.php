<?php if($errors->any()): ?>
    <?php foreach($errors->all() as $error): ?>
        <div class="alert alert-danger">
            <button type="button" aria-hidden="true" class="close" onclick="this.parentElement.style.display='none'">×</button>
            <span>
                                    <b> Danger - </b> <?php echo e($error); ?></span>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<?php if(session('successMsg')): ?>
    <div class="alert alert-success">
        <button type="button" aria-hidden="true" class="close" onclick="this.parentElement.style.display='none'">×</button>
        <span>
                                    <b> Success - </b> <?php echo e(session('successMsg')); ?></span>
    </div>
<?php endif; ?>