<?php /* Side Navigation */ ?>
<div class="col-md-2">
    <div class="sidebar content-box" style="display: block;">
           <ul class="nav">
            <!-- Main menu -->
            <li class="current"><a href="<?php echo e(route('admin.index')); ?>"><i class="glyphicon glyphicon-home"></i>
                    Dashboard</a></li>
            <li class="submenu">
                <a href="#">
                    <i class="glyphicon glyphicon-list"></i> Products
                    <span class="caret pull-right"></span>
                </a>
                <!-- Sub menu -->
                <ul>
                    <li><a href="<?php echo e(route('products.index')); ?>">Products</a></li>
                                      

                </ul>
            </li>
            <li class="submenu">
                <a href="#">
                    <i class="glyphicon glyphicon-list"></i> Category
                    <span class="caret pull-right"></span>
                </a>
                <!-- Sub menu -->
                <ul>
                    <li><a href="<?php echo e(route('category.index')); ?>">Add Category</a></li>
                </ul>
            </li>
            <li class="submenu">
                <a href="#">
                    <i class="glyphicon glyphicon-list"></i> Orders
                    <span class="caret pull-right"></span>
                </a>
                <!-- Sub menu -->
                <ul>
                    <li><a href="<?php echo e(url('admin/orders/pending')); ?>">Pending Orders</a></li>
                    <li><a href="<?php echo e(url('admin/orders/delivered')); ?>">Delivered Orders</a></li>
                    <li><a href="<?php echo e(url('admin/orders')); ?>">All Orders</a></li>
                </ul>
            </li>
        </ul>
		
		<ul class="nav">
            <li class="<?php echo e(Request::is('seller/dashboard*') ? 'active': ''); ?>">
                <a href="<?php echo e(route('seller.dashboard')); ?>">
                    <i class="material-icons"></i>
                    <p>Dashboard</p>
                </a>
            </li>
            <li class="<?php echo e(Request::is('seller/slider*') ? 'active': ''); ?>">
                <a href="<?php echo e(route('slider.index')); ?>">
                    <i class="material-icons"></i>
                    <p>Sliders</p>
                </a>
            </li>
            <li class="<?php echo e(Request::is('seller/category*') ? 'active': ''); ?>">
                <a href="<?php echo e(route('category.index')); ?>">
                    <i class="material-icons"></i>
                    <p>Categories</p>
                </a>
            </li>
            <li class="<?php echo e(Request::is('seller/item*') ? 'active': ''); ?>">
                <a href="<?php echo e(route('item.index')); ?>">
                    <i class="material-icons"></i>
                    <p>Items</p>
                </a>
            </li>
            <li class="<?php echo e(Request::is('seller/reservation*') ? 'active': ''); ?>">
                <a href="<?php echo e(route('reservation.index')); ?>">
                    <i class="material-icons"></i>
                    <p>Reservations</p>
                </a>
            </li>
            <li class="<?php echo e(Request::is('seller/contact*') ? 'active': ''); ?>">
                <a href="<?php echo e(route('contact.index')); ?>">
                    <i class="material-icons">message</i>
                    <p>Contact Message</p>
                </a>
            </li>

        </ul>
		
    </div>
	
	
</div> <!-- ADMIN SIDE NAV-->