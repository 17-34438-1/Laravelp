@extends('seller.layout.seller')
@section('content')
    <h3>WelcomeSecondHendBookManagement</h3>
@endsection