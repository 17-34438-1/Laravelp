@extends('layouts.main')

@section('content')
    <section class="hero text-center">
        <br/>
        <br/>
        <br/>
        <br/>
        <h2>
            <strong>
                Hey! Welcome to Online Books store
            </strong>
        </h2>
        <br>
        <a href="{{url('/shirts')}}">
            <button class="button large">Check out My BOOKS</button>
        </a>
    </section>
    <br/>
    <div class="subheader text-center">
        <h2>
            WELCOME&rsquo;s SECOND HAND BOOKS
        </h2>
    </div>

    <!-- Latest SHirts -->
    <div class="row">
        @forelse($shirts->chunk(4) as $chunk)
            @foreach($chunk as $shirt)
            <div class="small-3 medium-3 large-3 columns">
 <div class="item-wrapper">
                    <div class="img-wrapper">
                        <a href="{{route('cart.addItem',$shirt->id)}}"
						class="button expanded add-to-cart">
                            Add to Cart
                        </a>
                        <a href="#">
                            <img src="{{asset("images/$shirt->image")}}"/>
                        </a>
                    </div>
                
                        <h3>
						{{$shirt->name}}
                        </h3>
                    
                    <h5>
					 ${{$shirt->price}} 
                       
                    </h5>
                    <p>
					{{$shirt->description}}
                    </p>
                </div>

            </div>
            @endforeach 
        @empty
            <h3>No BOOks</h3>
        @endforelse
    </div>

    <!-- Footer -->
    <br>
@endsection




