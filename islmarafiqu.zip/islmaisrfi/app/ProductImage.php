<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductImage extends Model
{
    protected $guarded=[];

    public function products()
    {
    	return $this->belongsTo(Products::class);
    }
}
