<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/


Route::get('/','HomeController@index')->name('welcome');
Route::post('/reservation','ReservationController@reserve')->name('reservation.reserve');
Route::post('/contact','ContactController@sendMessage')->name('contact.send');

Route::auth();
Route::group(['prefix'=>'seller','middleware'=>'auth','namespace'=>'Admin'], function (){
    Route::get('dashboard', 'DashboardController@index')->name('seller.dashboard');
    Route::resource('slider','SliderController');
	    Route::get('seller/slider/{slider}/edit', 'SliderController@edit')->name('slider.edit');
			   Route::post('seller/slider/{slider}/edit', 'SliderController@update')->name('slider.update');

	   //Route::post('admin/slider/{slider}', 'SliderController@update')->name('slider.update');
	    Route::get('seller/slider', 'SliderController@index')->name('slider.index');
			    Route::post('seller/slider', 'SliderController@store');
			    //Route::post('admin/slider', 'SliderController@update');
	   Route::post('seller/slider/{slider}', 'SliderController@destroy')->name('slider.destroy');

	   Route::get('seller/slider/create', 'SliderController@create')->name('slider.create');
	   Route::post('seller/slider', 'SliderController@store')->name('slider.store');

    Route::resource('category','CategoryController');
	
		   Route::get('seller/category/create', 'CategoryController@create')->name('category.create');
	   Route::post('seller/category', 'CategoryController@store')->name('category.store');
	    Route::get('seller/category', 'CategoryController@index')->name('category.index');
	   Route::post('seller/category/{category}', 'CategoryController@destroy')->name('category.destroy');
	    Route::get('seller/category/{category}/edit', 'CategoryController@edit')->name('category.edit');
			   Route::post('seller/category/{category}/edit', 'CategoryController@update')->name('category.update');

    Route::resource('item','ItemController');
	  Route::get('seller/item/create', 'ItemController@create')->name('item.create');
	   Route::post('seller/item', 'ItemController@store')->name('item.store');
	    Route::get('seller/item', 'ItemController@index')->name('item.index');
	   Route::post('seller/item/{item}', 'ItemController@destroy')->name('item.destroy');
	    Route::get('seller/item/{item}/edit', 'ItemController@edit')->name('item.edit');
			   Route::post('seller/item/{item}/edit', 'ItemController@update')->name('item.update');
			       Route::resource('reservation','ReservationController');
      Route::post('reservation/{id}','ReservationController@status')->name('reservation.status');
    	   
 Route::get('reservation','ReservationController@index')->name('reservation.index');
 Route::post('seller/reservation/{reservation} ','ReservationController@destory')->name('reservation.destory');


    Route::get('contact','ContactController@index')->name('contact.index');

    Route::get('contact/{id}','ContactController@show')->name('contact.show');
    Route::post('contact/{id}','ContactController@destroy')->name('contact.destroy');
});


//Route::get('/home', 'HomeController@index');
Route::get('/', 'FrontController@index')->name('home');
//Route::get('/', 'FrontController@index')->name('front.shirts');

Route::get('/shirts', 'FrontController@shirts')->name('shirts');
Route::get('/shirt', 'FrontController@shirt')->name('shirt');
Route::auth();
Route::get('/logout', 'Auth\LoginController@logout');
Route::get('/home', 'HomeController@index');
Route::resource('/cart', 'CartController');
Route::get('/cart/add-item/{id}', 'CartController@addItem')->name('cart.addItem');

Route::get('/logout', 'Auth\LoginController@logout');
Route::group(['prefix' => 'admin'], function () {
   Route::post('toggledeliver/{orderId}', 'OrderController@toggledeliver')->name('toggle.deliver');

    Route::get('/', function () {
        return view('seller.index');
    })->name('seller.index');
	    Route::get('orders/{type?}', 'OrderController@Orders');

    Route::post('product/image-upload/{productId}','ProductsController@uploadImages');
	Route::resource('product','ProductsController');
	Route::resource('product','ProductsController1');
    Route::resource('categorys','CategoriesController');

	Route::post('admin/product', 'ProductsController@store')->name('product.store');
		  

		//Route::resource('/products', 'ProductsController@index');
Route::get('admin/product', 'ProductsController@index')->name('product.index');
  Route::post('admin/product/{product}','ProductsController@destroy')->name('product.destroy');
Route::get('/products', 'ProductsController@edit')->name('product.edit');
Route::get('admin/product/create', 'ProductsController@create')->name('product.create');

//Route::get('admin/product/{product}/edit', 'ProductsController1@edit')->name('product.edit');
Route::put('admin/product/{product}', 'ProductsController1@update')->name('product.update');

//Route::post('products', 'ProductsController@create')->name('products.create');
Route::get('/categorys', 'CategoriesController@index')->name('category.index');
//Route::post('categorys', 'CategoriesController@show')->name('category.show');
Route::post('/categorys', 'CategoriesController@store')->name('categorys.store');

Route::post('/category', 'CategoriesController@destroy')->name('category.destroy');


});
Route::resource('address','AddressController');
Route::group(['middleware' => 'auth'], function () {
    Route::get('shipping-info','CheckoutController@shipping')->name('checkout.shipping');
    //Route::resource('review','ProductReviewController');
});
Route::get('checkout','CheckoutController@step1');


Route::get('payment','CheckoutController@payment')->name('checkout.payment');
//Route::post('store-payment','CheckoutController@storePayment')->name('payment.store');
Route::post('store-payment','CheckoutController@storePayment')->name('payment.store');

