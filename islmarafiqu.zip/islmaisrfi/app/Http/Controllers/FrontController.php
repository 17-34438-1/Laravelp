<?php

namespace App\Http\Controllers;
use App\Products;
use App\Http\Requests;
use Illuminate\Http\Request;

class FrontController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
  
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $shirts=Products::all();

       return view('front.home',compact('shirts'));
	   return view('front.home');
    }
	
	public function shirts()
	{
		$shirts=new Products();
		 $shirts=Products::all();
        return view('front.shirts',compact('shirts'));
	  return view('front.shirts');	
	}
	public function shirt(Products $produc)
	{
	  return view('front.shirt',compact('produc'));	
	}
}
