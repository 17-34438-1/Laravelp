<?php

namespace App\Http\Controllers;
use App\Http\Requests;
use App\Category;
use App\Products;
use App\Product;
use Illuminate\Support\Facades\Mail;

use Illuminate\Http\Request;

class ProductsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $products=Products::all();
       return view('seller.product.index',compact('products'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
	{
		
		
        $categories=Category::pluck('name','id');
        return view('seller.product.create',compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $formInput=$request->except('image');

//        validation
        $this->validate($request,[
            'name'=>'required',
            'size'=>'required',
            'price'=>'required',
            'image'=>'required'
        ]);
//        image upload
        $image=$request->image;
        if($image){
            $imageName=$image->getClientOriginalName();
            $image->move('images',$imageName);
            $formInput['image']=$imageName;
        }

        Products::create($formInput);
        return redirect()->route('seller.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
              $products=Products::find($id);
        $categories=Category::pluck('name','id');
        return view('seller.product.edit',compact(['products','categories']));  
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
				    $products = new Products();

        $products=Products::find($id);
        $formInput=$request->except('image');

//        validation
    
   $this->validate($request,[
            'name'=>'required',
            'size'=>'required',
            'price'=>'required',
           // 'image'=>'image|mimes:png,jpg,jpeg|max:10000'
        ]);
        //        image upload
        $image=$request->image;
        if($image){
            $imageName=$image->getClientOriginalName();
            $image->move('images',$imageName);
            $formInput['image']=$imageName;
        }

         $products->update($formInput);
        return redirect()->route('product.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Products::destroy($id);
        return back();
    }

   public function uploadImages($productId,Request $request)
    {
		$products =Products::find($productId);
		
 $image=$request->file('file');
       

        if($image){
            $imageName=$image->getClientOriginalName();
            $image->move('images',$imageName);
           // $formInput['image']=$imageName;
		     $imagePath= "/images/$imageName";
		               $products->images()->create(['image_path'=>$imagePath]);

        }

        //Products::create($formInput);
    return "done";
        // Product::create($formInput);
    }

}